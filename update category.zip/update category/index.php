<?php

/**
* Plugin Name: Update Category
* Plugin URI: https://github.com/blueco/updatecategory
* Description: This plugin upgrade Category in WordPress
* Version: 1.0.0
* Author: Kitson Lai
* Author URI: https://github.com/blueco/updatecategory
* License: GPL2
*/

/* Notes to Examiner - Thank you for your time

* I was down with flu and taken medicine and drowsy. My first attempt was a total crap. 
* Here I attempt again after doing further reference to WP Codex and some research.
* There's still limitation for this plugin as there's no option for user to insert JSON URL.
* This plugin will update category based on JSON URL with matching ID with existing WordPress category ID.
* Looking forward to work with you and learn more codex usages if have the opportunity.

*/

//I want to make options page for the plugin or at least a page to response when 'Update Category Now' button clicked.
add_action('admin_menu', 'page_create');
function page_create() {
    $page_title = 'Update Category Admin';
    $menu_title = 'Update Categories Now';
    $capability = 'edit_posts';
    $menu_slug = 'category_update';
    $function = 'updateCategory';
    $icon_url = '';
    $position = 24;

    add_options_page( $page_title, $menu_title, $capability, $menu_slug, $function, $icon_url, $position );
}

//This will setup the cron interval of 30 minutes.
function cronInterval( $schedules ) {
 
    $schedules['every_thirty_minutes'] = array(
            'interval'  => 1800,
            'display'   => __( 'Every 30 Minutes', 'textdomain' )
    );
     
    return $schedules;
}
add_filter( 'cron_schedules', 'cronInterval' );

//Here I hook it for any cron manager plugin to pickup and clean deactivation when not required
if ( ! wp_next_scheduled( 'my_task_hook' ) ) {
  wp_schedule_event( time(), 'every_thirty_minutes', 'my_task_hook' );
}

add_action( 'my_task_hook', 'updateCategory' );

register_deactivation_hook(__FILE__, 'my_deactivation');

function my_deactivation() {
	wp_clear_scheduled_hook('my_task_hook');
}

//Created this function based on the api server created
function updateCategory() {
    
    $request = wp_remote_get( 'http://mypal.kitsonlai.com/db.json' );

    if( is_wp_error( $request ) ) {
        return false; // Will want to bail here if it's error
    }

/*
* I still think the following method was weak because it only assume the category or parent id remains the same.
* If JSON server parse different category ID in the string, it will not update.
* However, the reason for update I believe Parent-Child and ID remains the same.
* I have an idea to get parent ID with get_term( $term, $taxonomy, $output, $filter ) but I couldn't get the ObjectID output as category ID.
* Just in case there's a change in new ID for existing slug, this plugin is limited by it.
*/
    $body = wp_remote_retrieve_body( $request );
    $data = json_decode( $body );
    if( ! empty( $data ) ) { 
               
            foreach( $data->categories as $category ) {  
                $category_id = $category->id;        
                $my_cat = array('term_id' => $category->id,'name' => $category->name,'slug' => $category->name, 'parent' => $category->parent_id);                
                wp_update_term($category_id, 'category', $my_cat);                
            }
    

    }
    //I want to show some text and response when user click on 'Update Category Now' button on Settings
    include 'form.php';
    
}

?>